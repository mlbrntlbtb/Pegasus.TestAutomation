﻿using System.Reflection;

namespace Datacom.TestAutomation.Common.Extensions
{
    public class DirectoryExtensions
    {
        public string? GetAssemblyDirectory()
        {
            return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        }

        public string? GetParentDirectoryFromAssembly(string targetFolder)
        {
            string rootPath = Directory.GetParent(GetAssemblyDirectory()!)!.FullName;
            while (new DirectoryInfo(rootPath).GetDirectories()
                .Where(x => x.FullName.EndsWith(targetFolder)).Count() == 0)
            {
                rootPath = Directory.GetParent(rootPath)!.FullName;
            }
            return rootPath;
        }
    }
}
