﻿namespace Datacom.TestAutomation.Common
{
    public interface ITestSettings
    {
        string DownloadDirectory { get; set; }
    }
}
