﻿namespace Datacom.TestAutomation.Common
{
    public class ReportSettings
    {
        public string? Path { get; set; } = null;
    }
}
