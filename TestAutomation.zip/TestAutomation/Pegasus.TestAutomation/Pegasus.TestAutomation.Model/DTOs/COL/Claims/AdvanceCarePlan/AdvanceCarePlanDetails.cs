﻿
namespace Pegasus.TestAutomation.Model.DTOs
{
    public class AdvanceCarePlanDetails
    {
        public PatientInformationDetails? PatientInformationDetails { get; set; }
        public string? ConsultationDateFormat { get; set; }
        public ClaimantInformationDetails? ClaimantInformationDetails { get; set; }
        public DialogDetails? DialogDetails { get; set; }
    }
}
