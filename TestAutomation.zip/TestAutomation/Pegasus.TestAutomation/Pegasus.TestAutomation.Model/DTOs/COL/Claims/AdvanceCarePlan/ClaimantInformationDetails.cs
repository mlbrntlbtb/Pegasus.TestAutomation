﻿
namespace Pegasus.TestAutomation.Model.DTOs
{
    public class ClaimantInformationDetails
    {
        public string? Provider { get; set; }
        public string? Payee { get; set; }
    }

}
