﻿namespace Pegasus.TestAutomation.Model.DTOs
{
    public class PatientInformationDetails
    {
        public string? Name { get; set; }
        public string? Gender { get; set; }
        public string? DOB { get; set; }
        public string? NHI { get; set; }
        public string? Ethnicity { get; set; }
        public string? Address { get; set; }
    }
}
