﻿
namespace Pegasus.TestAutomation.Model.DTOs
{

    public class ClaimHistoryDetails
    {
        public int TableRowIndex { get; set; }
        public string? ServiceDateFormat { get; set; }
        public string? Service { get; set; }
        public string? Claim { get; set; }
        public string? Payee { get; set; }
        public string? Amount { get; set; }
        public string? Paid { get; set; }
        public string? Notes { get; set; }
    }

}
