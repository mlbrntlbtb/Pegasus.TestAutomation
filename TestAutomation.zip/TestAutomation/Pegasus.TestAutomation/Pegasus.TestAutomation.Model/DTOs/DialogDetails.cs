﻿
namespace Pegasus.TestAutomation.Model.DTOs
{
    public class DialogDetails
    {
        public string? DialogTitle { get; set; }
        public string? DialogContent { get; set; }
    }
}
