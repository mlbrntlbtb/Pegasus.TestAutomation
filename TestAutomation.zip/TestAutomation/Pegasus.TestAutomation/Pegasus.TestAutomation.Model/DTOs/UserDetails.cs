﻿namespace Pegasus.TestAutomation.Model.DTOs
{
    public class UserDetails
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
    }
}
