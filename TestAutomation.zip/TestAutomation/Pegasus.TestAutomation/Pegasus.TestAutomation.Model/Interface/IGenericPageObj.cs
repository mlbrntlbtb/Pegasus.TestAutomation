﻿
namespace Pegasus.TestAutomation.Model.Interface
{
    public interface IGenericPageObj
    {
    }
}
