﻿using OpenQA.Selenium;

namespace Pegasus.TestAutomation.Model.Interface
{
    public interface IPageElementContainer
    {
    }
}