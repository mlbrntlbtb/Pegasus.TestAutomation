﻿using AventStack.ExtentReports;

namespace Pegasus.TestAutomation.Model.Interface
{
    public interface IScreenCaptureService
    {
        public MediaEntityModelProvider CaptureScreenImage();
    }
}
