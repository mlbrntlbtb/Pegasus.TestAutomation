﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;
using Datacom.TestAutomation.Common;
using Datacom.TestAutomation.Common.Extensions;
using Pegasus.TestAutomation.Model.Settings;

namespace Pegasus.TestAutomation.Model.Services
{
    public class ExtentReporterService
    {
        private static readonly Lazy<ExtentReports> extent = new(() => new ExtentReports());

        public static ExtentReports Instance { get { return extent.Value; } }

        static ExtentReporterService()
        {
            var reporter = new ExtentV3HtmlReporter(GetTestDirectory());
            reporter.Config.Theme = Theme.Dark;
            Instance.AttachReporter(reporter);
        }

        public static string GetTestDirectory()
        {
            string reportPath = TestSettingsService.Instance.Load<ReportAppSettings>("ReportSettings").Path!;
            if (!Directory.Exists(reportPath))
            {
                string? rootPath = new DirectoryExtensions().GetParentDirectoryFromAssembly("TestAutomation");
                reportPath = Path.Combine(rootPath!, reportPath);
            }
            return reportPath + DateUtilities.GetCurrentDateTime("yyyyMMdd_HHmm") + ".html" ?? "/TestResults";
        }

        private ExtentReporterService()
        {
        }
    }
}
