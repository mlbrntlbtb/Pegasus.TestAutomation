﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.Extensions;
using Pegasus.TestAutomation.Model.Interface;

namespace Pegasus.TestAutomation.Model.Services
{
    public class ScreenCaptureService : IScreenCaptureService
    {
        private readonly IWebDriver driver;
        public ScreenCaptureService(IWebDriver driver)
        {
            this.driver = driver;
        }
        public MediaEntityModelProvider CaptureScreenImage()
        {
            return MediaEntityBuilder.CreateScreenCaptureFromBase64String(driver.TakeScreenshot().ToString()).Build();
        }

    }
}
