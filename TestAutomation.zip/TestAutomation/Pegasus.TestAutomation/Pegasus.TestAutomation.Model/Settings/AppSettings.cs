﻿namespace Pegasus.TestAutomation.Model.Settings
{
    public class AppSettings
    {
        public TestAppSettings? TestSettings { get; set; }
        public ReportAppSettings? ReportSettings { get; set; }
        public WebAppSettings? WebSettings { get; set; }
    }
}
