﻿namespace Pegasus.TestAutomation.Model.Settings
{
    public class ReportAppSettings
    {
        public string? Path { get; set; }
    }
}
