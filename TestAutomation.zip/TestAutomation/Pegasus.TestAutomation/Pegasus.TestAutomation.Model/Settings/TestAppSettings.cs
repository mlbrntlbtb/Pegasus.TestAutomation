﻿using System.Reflection;

namespace Pegasus.TestAutomation.Model.Settings
{
    public class TestAppSettings
    {
        public string? Browser { get; set; }
        public string? DriverPath { get; set; }
        public string? DownloadDirectory { get; set; }
        public int? DefaultTimeoutSeconds { get; set; }
        public bool? Headless { get; set; }
        public bool? EnableEventFiringWebDriver { get; set; }
        public bool? CloseBrowserAfterRun { get; set; }
        public bool? ReuseWebDriver { get; set; }
        public string? SessionID { get; set; }
        public string ExecutorURL { get; set; }
    }

}
