﻿namespace Pegasus.TestAutomation.Model.Settings
{
    public class WebAppSettings
    {
        public string? COL_BaseUrl { get; set; }
        public string? COL_DevUrl { get; set; }
        public string? COL_QAUrl { get; set; }
        public string? COL_SITUrl { get; set; }
        public string? COL_UATUrl { get; set; }
        public string? COLFACE_BaseUrl { get; set; }
        public string? COLFACE_DevUrl { get; set; }
        public string? COLFACE_QAUrl { get; set; }
        public string? COLFACE_SITUrl { get; set; }
        public string? COLFACE_UATUrl { get; set; }
    }
}
