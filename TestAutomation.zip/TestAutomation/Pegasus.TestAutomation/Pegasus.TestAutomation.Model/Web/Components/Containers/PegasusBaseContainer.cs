﻿using OpenQA.Selenium;
using Pegasus.TestAutomation.Model.Interface;

namespace Pegasus.TestAutomation.Model.Web.Components.PageContainers
{
    public class PegasusBaseContainer : IPageElementContainer
    {
        protected IWebElement ParentElement;

        public PegasusBaseContainer(IWebElement ParentElement)
        {
            this.ParentElement = ParentElement;
        }
    }
}