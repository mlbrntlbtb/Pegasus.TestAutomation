﻿using Datacom.TestAutomation.Web.Selenium;
using OpenQA.Selenium;
using ServiceStack;
using Pegasus.TestAutomation.Model.Interface;
using System.Diagnostics;
using Datacom.TestAutomation.Common;

namespace Pegasus.TestAutomation.Model.Web.Components.Elements
{
    public class DropDownList : IGenericPageObj
    {
        protected IWebDriver driver;
        private By dropDownListParentLocator = By.CssSelector("div[style*='display: block'] div[role='listbox']");
        private By dropDownListItemsLocator = By.CssSelector("div[role='option']");

        public DropDownList(IWebDriver driver)
        {
            this.driver = driver;
        }

        private List<IWebElement> GetDropDownListItems()
        {
            IWebElement parentElement = driver.GetElement(dropDownListParentLocator);
            return parentElement.GetElements(dropDownListItemsLocator).ToList();
        }

        public void Select(string dropDownListItemText, int customWait = 0)
        {
            bool isFound = false;
            WaitDropDownListToLoad(customWait);
            List<IWebElement> dropDownListItems = GetDropDownListItems();
            foreach (IWebElement dropDownListItem in dropDownListItems)
            {
                string dropDownListItemValue = dropDownListItem.Text.Trim();
                if (dropDownListItemValue.ToLower().Equals(dropDownListItemText.ToLower()))
                {
                    dropDownListItem.Click();
                    isFound = true;
                    break;
                }
            }
            if (!isFound)
                throw new Exception($"DropDownList item :['{dropDownListItemText}'] not found.");
        }

        public void WaitDropDownListToLoad(int customWait = 0)
        {
            if (customWait > 0)
                Thread.Sleep(new TimeSpan(0, 0, customWait));
            driver.WaitAvailability(dropDownListParentLocator);
        }
    }
}