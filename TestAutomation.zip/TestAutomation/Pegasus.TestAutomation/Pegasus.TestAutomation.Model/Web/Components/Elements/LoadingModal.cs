﻿using Datacom.TestAutomation.Web.Selenium;
using OpenQA.Selenium;

namespace Pegasus.TestAutomation.Model.Web.Components.Elements
{
    public class LoadingModal
    {
        protected IWebDriver driver;
        private By loadingModalLocator => By.CssSelector("div#PrevalDialog");

        public LoadingModal(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void WaitToDisappear()
        {
            driver.WaitUntilElementIsNotPresent(loadingModalLocator);
        }
    }
}