﻿using Datacom.TestAutomation.Web.Selenium;
using OpenQA.Selenium;
using Pegasus.TestAutomation.Model.Interface;

namespace Pegasus.TestAutomation.Model.Web.Components.Elements
{
    public class SideBar : IGenericPageObj
    {
        protected IWebDriver driver;
        private By sideBarParentLocator = By.CssSelector("ul#menulist");
        private By sideBarItemsLocator = By.CssSelector("li, li[class*='has-sub']");
        private By sideBarItemValueLocator = By.CssSelector("a span");

        public SideBar(IWebDriver driver)
        {
            this.driver = driver;
        }

        private List<IWebElement> GetSideBarItems()
        {
            IWebElement parentElement = driver.GetElement(sideBarParentLocator);
            return parentElement.GetElements(sideBarItemsLocator).ToList();
        }

        public void Select(string sideBarText, int customWait = 0)
        {
            bool isFound = false;
            WaitSideBarItemsToLoad(customWait);
            foreach (IWebElement sideBarItem in GetSideBarItems())
            {
                string sideBarItemValue = sideBarItem.GetElement(sideBarItemValueLocator).Text.Trim();
                if (sideBarItemValue.ToLower().Equals(sideBarText.ToLower()))
                {
                    sideBarItem.Click();
                    isFound = true;
                    break;
                }
            }

            if (!isFound)
                throw new Exception($"SideBar item :['{sideBarText}'] not found.");
        }

        public void WaitSideBarItemsToLoad(int customWait = 0)
        {
            if (customWait > 0)
                Thread.Sleep(new TimeSpan(0, 0, customWait));
            driver.WaitAvailability(sideBarItemsLocator);
        }
    }
}
