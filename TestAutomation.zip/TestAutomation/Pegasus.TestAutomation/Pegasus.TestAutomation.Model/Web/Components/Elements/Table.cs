﻿using Datacom.TestAutomation.Web.Selenium;
using OpenQA.Selenium;
using Pegasus.TestAutomation.Model.Interface;

namespace Pegasus.TestAutomation.Model.Web.Components.Elements
{
    public class Table : IGenericPageObj
    {
        protected IWebDriver driver;
        protected IWebElement parentElement;
        private By tableColumnsLocator = By.CssSelector("div[role='columnheader']");
        private By tableRowsLocator = By.CssSelector("div[role='row']");
        private By tableCellsLocator = By.CssSelector("div[role='gridcell']");

        public Table(IWebDriver driver, IWebElement parentElement)
        {
            this.driver = driver;
            this.parentElement = parentElement;
        }

        private List<IWebElement> GetTableColumns()
        {
            return parentElement.GetElements(tableColumnsLocator).ToList();
        }

        private List<IWebElement> GetTableRows()
        {
            return parentElement.GetElements(tableRowsLocator).ToList();
        }

        private List<IWebElement> GetTableCellsByRow(int rowIndex)
        {
            return GetTableRow(rowIndex).GetElements(tableCellsLocator).ToList();
        }

        private IWebElement GetTableCell(string columnName, int rowIndex)
        {
            int columnIndex = GetTableColumnIndexByName(columnName);
            return GetTableCellsByRow(rowIndex).ElementAt(columnIndex);
        }

        private int GetTableColumnIndexByName(string columnName)
        {
            int columnIndex = 0;
            int columnCount = GetTableColumns().Count;
            foreach (IWebElement tableColumn in GetTableColumns())
            {
                if (tableColumn.Text.Trim().ToLower().Equals(columnName.ToLower()))
                    break;
                else
                    columnIndex++;
            }
            return columnIndex <= columnCount ? columnIndex : -1;
        }

        private IWebElement GetTableRow(int rowIndex)
        {
            rowIndex = rowIndex > 0 ? rowIndex - 1 : rowIndex;
            return GetTableRows().ElementAt(rowIndex);
        }

        public string GetTableCellValue(string columnName, int rowIndex)
        {
            return GetTableCell(columnName, rowIndex).Text.Trim();
        }

        public void SelectTableRow(int rowIndex)
        {
            GetTableRow(rowIndex).Click();
        }
    }
}
