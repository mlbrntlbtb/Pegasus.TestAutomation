﻿using Datacom.TestAutomation.Common;
using Datacom.TestAutomation.Web.Selenium;
using OpenQA.Selenium;
using Pegasus.TestAutomation.Model.Web.Locators.Modals.COL;

namespace Pegasus.TestAutomation.Model.Web.Components.Modals
{
    public class DialogModal : PegasusBaseModal<DialogModal>, ILoadable<DialogModal>
    {
        private readonly IWebDriver driver;

        public DialogModal(IWebDriver driver)
            : base(driver)
        {
            this.driver = driver;
        }

        public IWebElement GetParentElement()
        {
            return driver.GetElement(DialogModalLocators.Container);
        }

        public string GetTitle()
        {
            return GetParentElement().GetElement(DialogModalLocators.Title).Text.Trim();
        }

        public string GetBody()
        {
            return GetParentElement().GetElement(DialogModalLocators.Body).Text.Trim();
        }

        public void ClickCloseButton()
        {
            GetParentElement().GetElement(DialogModalLocators.Button.Close).Click();
        }

        public void ClickPrimaryButton()
        {
            GetParentElement().GetElement(DialogModalLocators.Button.Primary).Click();
        }

        public void ClickDeleteButton()
        {
            GetParentElement().GetElement(DialogModalLocators.Button.Delete).Click();
        }

        public void ClickCancelButton()
        {
            GetParentElement().GetElement(DialogModalLocators.Button.Cancel).Click();
        }

        public void WaitDialogModalToDisappear()
        {
            driver.WaitUntilElementIsNotPresent(DialogModalLocators.Container);
        }

        protected override bool EvaluateLoadedStatus()
        {
            bool isDialogModalDisplayed = driver.IsElementPresent(DialogModalLocators.Container);
            bool isDialogTitleDisplayed = driver.IsElementPresent(DialogModalLocators.Title);
            bool isDialogBodyDisplayed = driver.IsElementPresent(DialogModalLocators.Body);
            return isDialogModalDisplayed && isDialogTitleDisplayed && isDialogBodyDisplayed;
        }
    }
}
