﻿using Datacom.TestAutomation.Web.Selenium;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Pegasus.TestAutomation.Model.Web.Components.Modals
{
    public abstract class PegasusBaseModal<T> : Loadable<T>, ILoadable<T>
        where T : LoadableComponent<T>
    {
        private readonly IWebDriver driver;

        public PegasusBaseModal(IWebDriver driver)
        {
            this.driver = driver;
        }

        protected override void ExecuteLoad() => driver.WaitForPageToLoad();
    }
}