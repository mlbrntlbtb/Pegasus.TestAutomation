﻿using Datacom.TestAutomation.Common;
using Datacom.TestAutomation.Web.Selenium;
using OpenQA.Selenium;
using Pegasus.TestAutomation.Model.DTOs;
using Pegasus.TestAutomation.Model.Web.Components.Elements;
using Pegasus.TestAutomation.Model.Web.Locators.Pages;

namespace Pegasus.TestAutomation.Model.Web.Components.Pages
{
    public class AdvanceCarePlanPage : PegasusBasePage<AdvanceCarePlanPage>, ILoadable<AdvanceCarePlanPage>
    {
        private readonly IWebDriver driver;
        private readonly LoadingModal loadingModal;
        private readonly DropDownList dropDownList;

        public AdvanceCarePlanPage(IWebDriver driver, LoadingModal loadingModal, DropDownList dropDownList)
            : base(driver)
        {
            this.driver = driver;
            this.loadingModal = loadingModal;
            this.dropDownList = dropDownList;
        }

        public void ClickSubmitButton()
        {
            driver.GetElement(AdvanceCarePlanLocators.Button.Submit).Click();
        }

        public void SetConsultationDate(string dateFormat)
        {
            string consultationDate = DateUtilities.GetCurrentDateTime(dateFormat);
            driver.GetElement(AdvanceCarePlanLocators.ClaimInformation.ConsultationDate)
                .SendKeys(consultationDate);
            loadingModal.WaitToDisappear();
        }

        public void SetClaimantInformation(ClaimantInformationDetails claimantInformation)
        {
            driver.GetElement(AdvanceCarePlanLocators.ClaimantInformation.Provider).Click();
            dropDownList.Select(claimantInformation.Provider!, 1);
            driver.GetElement(AdvanceCarePlanLocators.ClaimantInformation.Payee).Click();
            dropDownList.Select(claimantInformation.Payee!, 1);
            loadingModal.WaitToDisappear();
        }

        public bool ValidatePatientInformationMatch(PatientInformationDetails patientInformation)
        {
            bool isNameMatch = driver.GetElement(AdvanceCarePlanLocators.PatientInformation.Name, false)
                .IsElementTextEqualsTo(patientInformation.Name!);
            bool isGenderMatch = driver.GetElement(AdvanceCarePlanLocators.PatientInformation.Gender, false)
                .IsElementTextEqualsTo(patientInformation.Gender!);
            bool isDOBMatch = driver.GetElement(AdvanceCarePlanLocators.PatientInformation.DOB, false)
                .IsElementTextEqualsTo(patientInformation.DOB!);
            bool isNHIMatch = driver.GetElement(AdvanceCarePlanLocators.PatientInformation.NHI, false)
                .IsElementTextEqualsTo(patientInformation.NHI!);
            bool isEthnicityMatch = driver.GetElement(AdvanceCarePlanLocators.PatientInformation.Ethnicity, false)
                .IsElementTextEqualsTo(patientInformation.Ethnicity!);
            bool isAddressMatch = driver.GetElement(AdvanceCarePlanLocators.PatientInformation.Address, false)
                .IsElementTextEqualsTo(patientInformation.Address!);
            return isNameMatch && isGenderMatch && isDOBMatch && isNHIMatch && isEthnicityMatch && isAddressMatch;
        }

        protected override bool EvaluateLoadedStatus()
        {
            loadingModal.WaitToDisappear();
            InitializeFrame(LandingPageLocators.Frame.ContentContainer);
            bool isHeaderTitleDisplayed = driver.IsElementPresent(AdvanceCarePlanLocators.Label.HeaderTitle);
            return isHeaderTitleDisplayed;
        }
    }
}
