﻿using Datacom.TestAutomation.Web.Selenium;
using Microsoft.Extensions.Logging;
using OpenQA.Selenium;
using Pegasus.TestAutomation.Model.Settings;
using Pegasus.TestAutomation.Model.Web.Components.Elements;
using Pegasus.TestAutomation.Model.Web.Locators.Pages;

namespace Pegasus.TestAutomation.Model.Web.Components.Pages
{
    public class LandingPage : PegasusBasePage<LandingPage>, ILoadable<LandingPage>
    {
        private readonly IWebDriver driver;
        private readonly ILogger<LandingPage> logger;
        private readonly AppSettings settings;
        private SideBar sideBar;

        public LandingPage(ILogger<LandingPage> logger, AppSettings settings, IWebDriver driver, SideBar sideBar)
            : base(driver)
        {
            this.logger = logger;
            this.settings = settings;
            this.driver = driver;
            this.sideBar = sideBar;
        }

        public void SelectSideBarItem(string sideBarText)
        {
            InitializeFrame(LandingPageLocators.Frame.LeftNavContainer);
            sideBar.Select(sideBarText,1);
        }

        protected override bool EvaluateLoadedStatus()
        {
            bool isLeftNavContainerDisplayed = driver.IsElementPresent(LandingPageLocators.Frame.LeftNavContainer);
            bool isContentContainerDisplayed = driver.IsElementPresent(LandingPageLocators.Frame.ContentContainer);
            return isLeftNavContainerDisplayed & isContentContainerDisplayed;
        }

        protected override void ExecuteLoad()
        {
            string url = settings.WebSettings!.COL_BaseUrl!;
            logger.LogInformation("Navigating to URL: {url}", url);
            driver.NavigateTo(url);
        }
    }
}