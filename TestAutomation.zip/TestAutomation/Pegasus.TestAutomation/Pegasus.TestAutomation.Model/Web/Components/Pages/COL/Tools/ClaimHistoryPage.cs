﻿using Datacom.TestAutomation.Web.Selenium;
using OpenQA.Selenium;
using Pegasus.TestAutomation.Model.DTOs;
using Pegasus.TestAutomation.Model.Web.Locators.Pages;
using Pegasus.TestAutomation.Model.Web.Components.Elements;
using Datacom.TestAutomation.Common;

namespace Pegasus.TestAutomation.Model.Web.Components.Pages
{
    public class ClaimHistoryPage : PegasusBasePage<ClaimHistoryPage>, ILoadable<ClaimHistoryPage>
    {
        private readonly IWebDriver driver;

        public ClaimHistoryPage(IWebDriver driver)
            : base(driver)
        {
            this.driver = driver;
        }

        public void ClickDeleteButton()
        {
            driver.GetElement(ClaimHistoryLocators.Button.Delete).Click();
        }

        public void SelectTableRowClaimHistory(int rowIndex)
        {
            Table claimHistory = new Table(driver, driver.GetElement(ClaimHistoryLocators.Table.ClaimHistory));
            claimHistory.SelectTableRow(rowIndex);
        }

        public bool ValidateSubmittedClaimMatch(ClaimHistoryDetails claimHistoryDetails)
        {
            Table claimHistory = new Table(driver, driver.GetElement(ClaimHistoryLocators.Table.ClaimHistory));
            int tableRowIndex = claimHistoryDetails.TableRowIndex;
            bool isServiceDateMatch = claimHistory.GetTableCellValue("Service Date", tableRowIndex)
                .Equals(DateUtilities.GetCurrentDateTime(claimHistoryDetails.ServiceDateFormat!));
            bool isServiceMatch = claimHistory.GetTableCellValue("Service", tableRowIndex).Equals(claimHistoryDetails.Service!);
            bool isClaimMatch = claimHistory.GetTableCellValue("Claim", tableRowIndex).Equals(claimHistoryDetails.Claim!);
            bool isPayeeMatch = claimHistory.GetTableCellValue("Payee", tableRowIndex).Equals(claimHistoryDetails.Payee!);
            bool isAmountMatch = claimHistory.GetTableCellValue("Amount", tableRowIndex).Equals(claimHistoryDetails.Amount!);
            bool isPaidMatch = claimHistory.GetTableCellValue("Paid", tableRowIndex).Equals(claimHistoryDetails.Paid!);
            bool isNotesMatch = claimHistory.GetTableCellValue("Notes", tableRowIndex).Equals(claimHistoryDetails.Notes!);
            return isServiceDateMatch && isServiceMatch && isClaimMatch && isPayeeMatch && isAmountMatch && isPaidMatch && isNotesMatch;
        }

        protected override bool EvaluateLoadedStatus()
        {
            InitializeFrame(LandingPageLocators.Frame.ContentContainer);
            bool isHeaderTitleDisplayed = driver.IsElementPresent(ClaimHistoryLocators.Label.HeaderTitle);
            return isHeaderTitleDisplayed;
        }
    }
}
