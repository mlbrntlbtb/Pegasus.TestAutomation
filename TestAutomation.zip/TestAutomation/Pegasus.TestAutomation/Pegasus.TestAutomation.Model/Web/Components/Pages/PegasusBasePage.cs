﻿using Datacom.TestAutomation.Web.Selenium;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Pegasus.TestAutomation.Model.Web.Components.Pages
{
    public abstract class PegasusBasePage<T> : Loadable<T>, ILoadable<T>
        where T : LoadableComponent<T>
    {
        private readonly IWebDriver driver;

        public PegasusBasePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void InitializeFrame(By locator)
        {
            driver.SwitchTo().ParentFrame();
            driver.SwitchTo().Frame(driver.GetElement(locator));
        }

        public void RevertFrame()
        {
            driver.SwitchTo().ParentFrame();
        }

        protected override void ExecuteLoad() => driver.WaitForPageToLoad();
    }
}