﻿
using OpenQA.Selenium;

namespace Pegasus.TestAutomation.Model.Web.Locators.Modals.COL
{
    public static class DialogModalLocators
    {
        public static By Container => By.CssSelector("div[class*='bootbox modal']");
        public static By Title => By.CssSelector("h5[class='modal-title']");
        public static By Body => By.CssSelector("div[class='bootbox-body']");
        
        public static class Button
        {
            public static By Close => By.CssSelector("button[class*='bootbox-close']");
            public static By Primary => By.CssSelector("button[class*='btn-primary']");
            public static By Delete => By.CssSelector("button[class*='btn-success']");
            public static By Cancel => By.CssSelector("button[class*='btn-danger']");
        }
    }
}
