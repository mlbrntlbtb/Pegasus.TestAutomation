﻿using OpenQA.Selenium;

namespace Pegasus.TestAutomation.Model.Web.Locators.Pages;

public static class AdvanceCarePlanLocators
{
    public static class Label
    {
        public static By HeaderTitle => By.CssSelector("div#claimTitle");
    }

    public static class PatientInformation
    {
        public static By Name => By.CssSelector("input#patientName");
        public static By Gender => By.CssSelector("input#patientGender");
        public static By DOB => By.CssSelector("input#patientDOB");
        public static By NHI => By.CssSelector("input#patientNHI");
        public static By Ethnicity => By.CssSelector("input#patientEthnicity");
        public static By Address => By.CssSelector("input#patientAddress");
    }

    public static class ClaimInformation
    {
        public static By ConsultationDate => By.CssSelector("input#inputSERVICE_DATE");
    }

    public static class ClaimantInformation
    {
        public static By Provider => By.CssSelector("div#dropdownlistWrapperNZMC");
        public static By Payee => By.CssSelector("div#dropdownlistWrapperPAYEE_NUMBER");
    }

    public static class Button
    {
        public static By ClaimHelp => By.CssSelector("a#help-link");
        public static By Submit => By.CssSelector("button#btnSubmit");
    }
}