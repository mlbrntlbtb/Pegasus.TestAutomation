﻿using OpenQA.Selenium;

namespace Pegasus.TestAutomation.Model.Web.Locators.Pages;

public static class LandingPageLocators
{
    public static class Frame
    {
        public static By LeftNavContainer => By.CssSelector("iframe#frameLeftNav"); //Frame for all elements in left navigation container
        public static By ContentContainer => By.CssSelector("iframe#frameContent"); //Frame for all elements in content container
    }
    public static class Menu
    {
        public static By LeftNav => By.CssSelector("ul#menulist");
    }

    public static class Label
    {
        public static By LandingPageInfo => By.CssSelector("div#landingpageInfo");
    }
}