﻿
using OpenQA.Selenium;

namespace Pegasus.TestAutomation.Model.Web.Locators.Pages
{
    public static class ClaimHistoryLocators
    {
        public static class Label
        {
            public static By HeaderTitle => By.CssSelector("span.panel-heading");
        }

        public static class Table
        {
            public static By ClaimHistory => By.CssSelector("div#claimGrid");
        }

        public static class CheckBox
        {
            public static By IncludePaidClaims => By.CssSelector("input#chkGetAll");
        }

        public static class Button
        {
            public static By Delete => By.CssSelector("button#btnDelete");
        }
    }
}
