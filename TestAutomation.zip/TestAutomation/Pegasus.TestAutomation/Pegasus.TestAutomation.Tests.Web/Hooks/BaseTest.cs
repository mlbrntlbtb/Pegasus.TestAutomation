﻿using AventStack.ExtentReports;
using Datacom.TestAutomation.Common;
using Microsoft.Extensions.Logging;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.Extensions;
using Pegasus.TestAutomation.Model.DTOs;
using Pegasus.TestAutomation.Model.Extensions;
using Pegasus.TestAutomation.Model.Interface;
using Pegasus.TestAutomation.Model.Services;

namespace Pegasus.TestAutomation.Tests.Web
{
    //[Parallelizable(ParallelScope.Fixtures)] -- Use Parellizable for parallel testing only
    public class BaseTest
    {
        protected WebTestSession? TestSession;
        protected ExtentTest? Test;
        protected ExtentTest? ChildTest;
        protected IComponentFactory? PageFactory;
        protected ILogger<BaseTest>? Logger;
        protected IScreenCaptureService? ScreenCaptureService;
        protected UserDetails? AdminUser;
        protected WebSettings? WebSettings;

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            TestSession = new WebTestSession();
            TestSession.Start();

            PageFactory = TestSession!.Resolve<IComponentFactory>();
            Logger = TestSession!.Resolve<ILogger<BaseTest>>();
            ScreenCaptureService = TestSession!.Resolve<IScreenCaptureService>();
            WebSettings = TestSession!.Resolve<WebSettings>();

            //========================================================================================
            //Load Test Data
            //========================================================================================
            AdminUser = TestDataService.Instance.Load<UserDetails>("TestUsers:Admin");
        }

        [SetUp]
        public void SetUp()
        {
            Test = TestSession!.GetReporter().CreateTest($"{TestSession.GetTestName()}");
            Logger!.LogInformation("Start {name}", TestSession.GetTestName());
        }

        [TearDown]
        public void TearDown()
        {
            if (TestSession!.GetContext().Result.Outcome != ResultState.Success)
            {
                Logger!.LogFail(Test!, $"Test failed due to {TestSession.GetContext().Result.Message}",
                    MediaEntityBuilder.CreateScreenCaptureFromBase64String(TestSession!.Resolve<IWebDriver>().TakeScreenshot().ToString()).Build());
            }

            TestSession!.Stop();

            Logger!.LogDebug("Test Directory: {path}", ExtentReporterService.GetTestDirectory());
            TestContext.WriteLine(ExtentReporterService.GetTestDirectory());
        }
    }
}