﻿using AventStack.ExtentReports;
using Datacom.TestAutomation.Common;
using Microsoft.Extensions.Logging;
using OpenQA.Selenium;
using Pegasus.TestAutomation.Model.Services;
using ServiceStack;

namespace Pegasus.TestAutomation.Tests.Web
{
    public class WebTestSession : TestSession<WebTestSession>
    {
        public override void Start()
        {
            base.Start();

            if (!Resolve<WebSettings>().ReuseWebDriver)
            {
                Logger!.LogDebug("SessionID: {sessionId}", Resolve<IWebDriver>().GetSessionId());
                Logger!.LogDebug("ExecutorURL: {executorURL}", Resolve<IWebDriver>().GetExecutorURL());
            }
        }

        public override void Stop()
        {
            Logger!.LogDebug("Generate report");
            GetReporter().Flush();

            if (Resolve<WebSettings>().CloseBrowserAfterRun)
            {
                Logger!.LogDebug("Stop webdriver");
                Resolve<IWebDriver>().Quit();
                Resolve<IWebDriver>().Dispose();
                base.Stop();
            }
        }

        public override string GetTestName()
        {
            //return TestContext.CurrentContext.Test.Name;
            return TestContext.CurrentContext.Test.MethodName!; //Get method name instead
        }

        public override TestContext GetContext()
        {
            return TestContext.CurrentContext;
        }

        public override ExtentReports GetReporter()
        {
            return ExtentReporterService.Instance;
        }
    }
}