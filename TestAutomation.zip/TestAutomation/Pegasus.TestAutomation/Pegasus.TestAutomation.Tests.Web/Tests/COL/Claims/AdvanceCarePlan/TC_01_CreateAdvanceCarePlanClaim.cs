﻿using Datacom.TestAutomation.Common;
using Microsoft.Extensions.Logging;
using Pegasus.TestAutomation.Model.DTOs;
using Pegasus.TestAutomation.Model.Extensions;
using Pegasus.TestAutomation.Model.Web.Components.Modals;
using Pegasus.TestAutomation.Model.Web.Components.Pages;

namespace Pegasus.TestAutomation.Tests.Web.Tests
{
    [TestFixture]
    [Category("AdvanceCarePlan")]
    [Order(1)]
    public class TC_01_CreateAdvanceCarePlanClaim : BaseTest
    {
        /******************************************************************************
        * *************************  Ticket number : 01 *******************************
        * Given: I navigate to Advance Care Plan page under Claims module
        * When: I provide correct information for an Advance Care Plain claim
        * Then: Advance Care Plan claim submission will be successful
        ******************************************************************************/

        [Test]
        [TestCase(@"AdvanceCarePlan\TD_01\TC_01_CreateAdvanceCarePlanClaim")]
        //[TestCase(@"AdvanceCarePlan\TD_02\TC_01_CreateAdvanceCarePlanClaim")]
        public void TestCase_CreateAdvanceCarePlanClaim(string TestData)
        {
            //Initialization of Page Elements
            //========================================================================
            LandingPage landingPage = PageFactory!.GetComponent<LandingPage>().Load();
            AdvanceCarePlanPage advanceCarePlanPage = PageFactory!.GetComponent<AdvanceCarePlanPage>();
            DialogModal dialogModal = PageFactory!.GetComponent<DialogModal>();

            //Initialization of Test Data
            //========================================================================
            AdvanceCarePlanDetails advanceCarePlanDetails = TestDataService.Instance.LoadFile<AdvanceCarePlanDetails>(TestData);

            //Step 1: Load Pegasus Claims Online Landing page
            //Expected Result: Pegasus Landing page is loaded
            //========================================================================
            ChildTest = Test!.CreateNode("Step 1: Load Pegasus Claims Online Landing Page");
            landingPage.IsLoaded.Should().BeTrue();
            Logger!.LogPass(ChildTest!, "Pegasus Claims Online Landing page is loaded");

            //Step 2: Navigate to Advance Care Plan Claims page
            //Expected Result: Advance Care Plan Claims page is loaded
            //========================================================================
            ChildTest = Test!.CreateNode("Step 2: Navigate to Advance Care Plan Claims page");
            landingPage.SelectSideBarItem("CLAIMS");
            landingPage.SelectSideBarItem("Advance Care Plan");
            advanceCarePlanPage.IsLoaded.Should().BeTrue();
            Logger!.LogPass(ChildTest!, "Advance Care Plan Claims page is loaded", ScreenCaptureService!.CaptureScreenImage());

            //Step 3: Validate Patient Information details from Advance Care Plan Claims page
            //Expected Result: Patient information details should match expected test data
            //========================================================================
            ChildTest = Test!.CreateNode("Step 3: Validate patient information from Advance Care Plan Claims page");
            advanceCarePlanPage.ValidatePatientInformationMatch(advanceCarePlanDetails.PatientInformationDetails!);
            Logger!.LogPass(ChildTest!, "Patient information details has matched the expected test data", ScreenCaptureService!.CaptureScreenImage());

            //Step 4: Set consultation date from Claim Information pane
            //Expected Result: Consultation date should be set from Claim Information pane
            //========================================================================
            ChildTest = Test!.CreateNode("Step 4: Set consultation date from Claim Information pane");
            advanceCarePlanPage.SetConsultationDate(advanceCarePlanDetails.ConsultationDateFormat!);
            Logger!.LogPass(ChildTest!, "Consultation date has been set from Claim Information pane");

            //Step 5: Set provider and payee details from Claimant Information
            //Expected Result: Provider and payee should be set from Claimant Information pane
            //========================================================================
            ChildTest = Test!.CreateNode("Step 5: Set provider and payee details from Claimant Information");
            advanceCarePlanPage.SetClaimantInformation(advanceCarePlanDetails.ClaimantInformationDetails!);
            Logger!.LogPass(ChildTest!, "Provider and payee has been set from Claimant Information pane", ScreenCaptureService!.CaptureScreenImage());

            //Step 6: Submit Advance Care Plan Claim
            //Expected Result: Claim Successful modal dialog should appear
            //========================================================================
            ChildTest = Test!.CreateNode("Step 6: Submit Advance Care Plan Claim");
            advanceCarePlanPage.ClickSubmitButton();
            dialogModal.IsLoaded.Should().BeTrue();
            dialogModal.GetTitle().Should().BeEquivalentTo(advanceCarePlanDetails.DialogDetails!.DialogTitle!);
            dialogModal.GetBody().Should().Contain(advanceCarePlanDetails.DialogDetails!.DialogContent!);
            Logger!.LogPass(ChildTest!, "Claim Successful modal dialog has appeared", ScreenCaptureService!.CaptureScreenImage());
            dialogModal.ClickCloseButton();
        }
    }
}