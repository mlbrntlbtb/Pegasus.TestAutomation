﻿using Datacom.TestAutomation.Common;
using Pegasus.TestAutomation.Model.DTOs;
using Pegasus.TestAutomation.Model.Extensions;
using Pegasus.TestAutomation.Model.Web.Components.Modals;
using Pegasus.TestAutomation.Model.Web.Components.Pages;

namespace Pegasus.TestAutomation.Tests.Web.Tests
{
    [TestFixture]
    [Category("AdvanceCarePlan")]
    [Order(2)]
    public class TC_02_ReadAdvanceCarePlanClaim : BaseTest
    {
        /******************************************************************************
        * *************************  Ticket number : 02 *******************************
        * Given: == I have submitted an Advance Care Plan claim
        * When: == I navigate to @TargetPage page
        * Then: == @ExpectedResult will be displayed
        ******************************************************************************/

         /* Parameters: 
         ********************************************************************************
         | @TargetPage       | @ExpectedResult                                          |            
         | Advance Care Plan | Modal with message 'One ACP claim permitted per person'  |
         | Claim History     | Submitted Advance Care Plan claim on Claim History table |
         *******************************************************************************/

        [Test]
        [TestCase(@"AdvanceCarePlan\TD_01\TC_02_ReadAdvanceCarePlanClaim")]
        //[TestCase(@"AdvanceCarePlan\TD_02\TC_02_ReadAdvanceCarePlanClaim")]
        public void TestCase_ReadAdvanceCarePlanClaim(string TestData)
        {
            //Initialization of Page Elements
            //========================================================================
            LandingPage landingPage = PageFactory!.GetComponent<LandingPage>().Load();
            AdvanceCarePlanPage advanceCarePlanPage = PageFactory!.GetComponent<AdvanceCarePlanPage>();
            DialogModal dialogModal = PageFactory!.GetComponent<DialogModal>();
            ClaimHistoryPage claimHistoryPage = PageFactory!.GetComponent<ClaimHistoryPage>();

            //Initialization of Test Data
            //========================================================================
            DialogDetails dialogDetails = TestDataService.Instance.LoadFile<DialogDetails>(TestData, "DialogDetails");
            ClaimHistoryDetails claimHistoryDetails = TestDataService.Instance.LoadFile<ClaimHistoryDetails>(TestData, "ClaimHistoryDetails");

            //Step 1: Load Pegasus Claims Online Landing page
            //Expected Result: Pegasus Landing page is loaded
            //========================================================================
            ChildTest = Test!.CreateNode("Step 1: Load Pegasus Claims Online Landing Page");
            landingPage.IsLoaded.Should().BeTrue();
            Logger!.LogPass(ChildTest!, "Pegasus Claims Online Landing page is loaded");

            //Step 2: Navigate to Advance Care Plan Claims page
            //Expected Result: Advance Care Plan Claims page is loaded
            //========================================================================
            ChildTest = Test!.CreateNode("Step 2: Navigate to Advance Care Plan Claims page");
            landingPage.SelectSideBarItem("CLAIMS");
            landingPage.SelectSideBarItem("Advance Care Plan");
            advanceCarePlanPage.IsLoaded.Should().BeTrue();
            Logger!.LogPass(ChildTest!, "Advance Care Plan Claims page is loaded", ScreenCaptureService!.CaptureScreenImage());

            //Step 3: Validate an Advance Care Plan Claim has already been submitted
            //Expected Result: Modal with message 'One ACP claim permitted per person' should appear
            //========================================================================
            ChildTest = Test!.CreateNode("Step 3: Validate an Advance Care Plan Claim has already been submitted");
            dialogModal.IsLoaded.Should().BeTrue();
            dialogModal.GetTitle().Should().BeEquivalentTo(dialogDetails.DialogTitle!);
            dialogModal.GetBody().Should().Contain(dialogDetails.DialogContent!);
            Logger!.LogPass(ChildTest!, "Modal with message 'One ACP claim permitted per person' has appeared", ScreenCaptureService!.CaptureScreenImage());
            dialogModal.ClickCloseButton();

            //Step 4: Navigate to Claim History page
            //Expected Result: Claim History page is loaded
            //========================================================================
            ChildTest = Test!.CreateNode("Step 4: Navigate to Claim History page");
            landingPage.SelectSideBarItem("TOOLS");
            landingPage.SelectSideBarItem("Claim History");
            claimHistoryPage.IsLoaded.Should().BeTrue();
            Logger!.LogPass(ChildTest!, "Claim History page is loaded", ScreenCaptureService!.CaptureScreenImage());

            //Step 5: Validate submitted Advance Care Plan claim exists on Claim History table
            //Expected Result: Submitted Advance Care Plan claim should exist on Claim History table
            //========================================================================
            ChildTest = Test!.CreateNode("Step 5: Validate submitted Advance Care Plan claim exists on Claim History table");
            claimHistoryPage.ValidateSubmittedClaimMatch(claimHistoryDetails!);
            Logger!.LogPass(ChildTest!, "Submitted Advance Care Plan claim is found existing on Claim History table", ScreenCaptureService!.CaptureScreenImage());
        }
    }
}
