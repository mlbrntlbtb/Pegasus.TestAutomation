﻿
using Datacom.TestAutomation.Common;
using Pegasus.TestAutomation.Model.DTOs;
using Pegasus.TestAutomation.Model.Extensions;
using Pegasus.TestAutomation.Model.Web.Components.Modals;
using Pegasus.TestAutomation.Model.Web.Components.Pages;

namespace Pegasus.TestAutomation.Tests.Web.Tests
{
    [TestFixture]
    [Category("AdvanceCarePlan")]
    [Order(3)]
    public class TC_03_DeleteAdvanceCarePlanClaim : BaseTest
    {
        /******************************************************************************
        * *************************  Ticket number : 03 *******************************
        * Given: I navigate to Claim History page
        * When: I delete a submitted unapproved/unpaid Advance Care Plan claim
        * Then: Submitted Advance Care Plan claim will be deleted from Claim History
        ******************************************************************************/

        [Test]
        [TestCase(@"AdvanceCarePlan\TD_01\TC_03_DeleteAdvanceCarePlanClaim")]
        //[TestCase(@"AdvanceCarePlan\TD_02\TC_03_DeleteAdvanceCarePlanClaim")]
        public void TestCase_DeleteAdvanceCarePlanClaim(string TestData)
        {
            //Initialization of Page Elements
            //========================================================================
            LandingPage landingPage = PageFactory!.GetComponent<LandingPage>().Load();
            DialogModal dialogModal = PageFactory!.GetComponent<DialogModal>();
            ClaimHistoryPage claimHistoryPage = PageFactory!.GetComponent<ClaimHistoryPage>();

            //Initialization of Test Data
            //========================================================================
            ClaimHistoryDetails claimHistoryDetails = TestDataService.Instance.LoadFile<ClaimHistoryDetails>(TestData, "ClaimHistoryDetails");
            DialogDetails dialogDetails = TestDataService.Instance.LoadFile<DialogDetails>(TestData, "DialogDetails");

            //Step 1: Load Pegasus Claims Online Landing page
            //Expected Result: Pegasus Landing page is loaded
            //========================================================================
            ChildTest = Test!.CreateNode("Step 1: Load Pegasus Claims Online Landing Page");
            landingPage.IsLoaded.Should().BeTrue();
            Logger!.LogPass(ChildTest!, "Pegasus Claims Online Landing page is loaded");

            //Step 2: Navigate to Claim History page
            //Expected Result: Claim History page is loaded
            //========================================================================
            ChildTest = Test!.CreateNode("Step 2: Navigate to Claim History page");
            landingPage.SelectSideBarItem("TOOLS");
            landingPage.SelectSideBarItem("Claim History");
            claimHistoryPage.IsLoaded.Should().BeTrue();
            Logger!.LogPass(ChildTest!, "Claim History page is loaded");

            //Step 3: Select submitted Advance Care Plan claim's row from Claim History table
            //Expected Result: Submitted Advance Care Plan claim will be selected from Claim History table
            //========================================================================
            ChildTest = Test!.CreateNode("Step 3: Select submitted Advance Care Plan claim's row from Claim History table");
            claimHistoryPage.ValidateSubmittedClaimMatch(claimHistoryDetails!);
            claimHistoryPage.SelectTableRowClaimHistory(claimHistoryDetails.TableRowIndex!);
            Logger!.LogPass(ChildTest!, "Submitted Advance Care Plan claim is selected from Claim History table", ScreenCaptureService!.CaptureScreenImage());

            //Step 4: Delete selected row from Claim History table
            //Expected Result: Modal with message 'Claim to be Deleted' should appear
            //========================================================================
            ChildTest = Test!.CreateNode("Step 4: Delete selected row from Claim History table");
            claimHistoryPage.ClickDeleteButton();
            dialogModal.IsLoaded.Should().BeTrue();
            dialogModal.GetTitle().Should().BeEquivalentTo(dialogDetails.DialogTitle!);
            dialogModal.GetBody().Should().Contain(dialogDetails.DialogContent!);
            Logger!.LogPass(ChildTest!, "Modal with message 'Claim to be Deleted' has appeared", ScreenCaptureService!.CaptureScreenImage());

            //Step 5: Confirm deletion from Modal
            //Expected Result: Submitted Advance Care Plan claim should not exist from Claim History table
            //========================================================================
            ChildTest = Test!.CreateNode("Step 5: Delete selected row from Claim History table");
            dialogModal.ClickDeleteButton();
            dialogModal.WaitDialogModalToDisappear();
            Logger!.LogPass(ChildTest!, "Submitted Advance Care Plan claim does not exist from Claim History table", ScreenCaptureService!.CaptureScreenImage());
        }
    }
}
