global using Datacom.TestAutomation.Web.Selenium;
global using FluentAssertions;
global using NUnit.Framework;
global using Pegasus.TestAutomation.Model;
global using Pegasus.TestAutomation.Model.Web;